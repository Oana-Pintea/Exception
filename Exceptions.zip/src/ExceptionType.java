public enum ExceptionType {
    GENDER_TEXT,
    CNP_TEXT,
    AGE_LIMIT,
    NAME_EMPTY,
    HETERO_ONLY,
    ID_EMPTY,
    STUDENT_ID_NOT_FOUND,
    AGE_NEGATIVE
}
